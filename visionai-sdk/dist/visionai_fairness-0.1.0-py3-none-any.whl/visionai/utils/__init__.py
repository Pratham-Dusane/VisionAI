"""VisionAI utility helpers."""
